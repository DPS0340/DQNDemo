import gym
import numpy as np
from numpy.core.fromnumeric import shape
import torch
from torch._C import device
import torch.nn as nn
import torch.nn.functional as F
import math
import random
from collections import deque
import sys

def get_demo_traj():
    return np.load("./demo_traj_2.npy", allow_pickle=True)

##########################################################################
############                                                  ############
############                  DQfDNetwork 구현                 ############
############                                                  ############
##########################################################################

PRETRAIN_STEP = 1000

class DQfDNetwork(nn.Module):
    def __init__(self, in_size, out_size):
        super(DQfDNetwork, self).__init__()
        HIDDEN_SIZE = 64
        self.f1 = nn.Linear(in_size, HIDDEN_SIZE)
        self.f2 = nn.Linear(HIDDEN_SIZE, HIDDEN_SIZE)
        self.f3 = nn.Linear(HIDDEN_SIZE, out_size)
        nn.init.xavier_uniform_(self.f1.weight)
        nn.init.xavier_uniform_(self.f2.weight)
        self.opt = torch.optim.Adam(self.parameters(), lr=0.001)
        self.loss = torch.nn.MSELoss()

    def forward(self,x):
        x1 = F.relu6(self.f1(x))
        x2 = F.relu6(self.f2(x1))
        x3 = self.f3(x2)
        res = F.softmax(x3)
        return res

class Memory():
    def __init__(self, length=500):
        self.idx = 0
        self.length = length
        self.container = [None for _ in range(length)]
        self.max = 0
    def push(self, obj):
        if self.idx == 500:
            self.idx = 0
        self.container[self.idx] = obj
        self.idx += 1
        self.max = max(self.max, self.idx-1)
    def sample(self):
        choice = random.randint(0, self.max)
        return self.container[choice]
    
##########################################################################
############                                                  ############
############                  DQfDagent 구현                   ############
############                                                  ############
##########################################################################

class DQfDAgent(object):
    def __init__(self, env, use_per, n_episode):
        self.n_EPISODES = n_episode
        self.env = env
        self.use_per = use_per
        self.gamma = 0.99
        self.epsilon = 1.0
        self.epsilon_decay = 0.999
        self.epsilon_min = 0.001
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        env.render()
        state_size = env.observation_space.shape[0]
        action_size = env.action_space.n
        self.policy_network = DQfDNetwork(state_size, action_size).to(self.device)
        self.target_network = DQfDNetwork(state_size, action_size).to(self.device)
        self.frequency = 1
        self.memory = Memory()
        print('device is', self.device)
    
    def get_action(self, state):
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
        # epsilon-greedy 적용 #
        randint = random.random()
        if randint <= self.epsilon:
            return random.randint(0, 1)
        else:
            self.policy_network.eval()
            predicted = self.policy_network.forward(state).to(self.device)
            action = torch.argmax(predicted)
            action = action.cpu().numpy()
            return action
    

    def train_network(self, args=None, pretrain=False):
        # 람다값 임의로 설정 #
        l1 = l2 = l3 = 0.1

        if pretrain:
            self.n = 20
            minibatch = self.sample_minibatch()
        else:
            self.n = 1
            minibatch = [args]

        for episode in range(self.n):
            state, action, reward, next_state, done = minibatch[episode]
            state = torch.from_numpy(state).float().to(self.device)
            next_state = torch.from_numpy(next_state).float().to(self.device)
            next_state.requires_grad = True
            # double_dqn_loss 계산 # 
            double_dqn_loss = self.target_network(next_state).to(self.device).max()
            double_dqn_loss = double_dqn_loss * self.gamma
            double_dqn_loss = double_dqn_loss - self.target_network(state).to(self.device).max()
            double_dqn_loss = double_dqn_loss + reward
            double_dqn_loss = torch.pow(double_dqn_loss, 2)
            def margin(action1, action2):
                if action1 == action2:
                    return torch.Tensor([0]).to(self.device)
                return torch.Tensor([0.2]).to(self.device)
            # margin_classification_loss 계산 #
            partial_margin_classification_loss = torch.Tensor([0])
            partial_margin_classification_loss = partial_margin_classification_loss.to(self.device)
            for selected_action in range(2):
                __state__, _, _, _ = self.env.step(selected_action)
                __state__ = torch.from_numpy(__state__).float().to(self.device)
                expect = self.target_network(__state__).to(self.device).max()
                partial_margin_classification_loss = max(partial_margin_classification_loss, expect + margin(action, selected_action))
            margin_classification_loss = partial_margin_classification_loss - self.target_network(state).to(self.device).max()
            # n-step returns 계산 #
            n_step_returns = torch.Tensor([reward])
            n_step_returns = n_step_returns.to(self.device)
            current_n_step_action = action
            current_n_step_state, current_reward, __done__, _ = self.env.step(current_n_step_action)
            for exp in range(1, self.n):
                if __done__:
                    break
                current_n_step_state = torch.from_numpy(current_n_step_state).float().to(self.device)
                current_n_step_action = self.target_network(current_n_step_state).to(self.device).max()
                current_n_step_state, current_reward, __done__, _ = self.env.step(action)
                n_step_returns = n_step_returns + (self.gamma ** exp) * current_reward
            partial_n_step_returns = torch.Tensor([0]).to(self.device)
            for selected_action in range(2):
                __state__, _, _, _ = self.env.step(selected_action)
                __state__ = torch.from_numpy(__state__).float().to(self.device)
                expect = self.target_network(__state__).to(self.device).max()
                partial_n_step_returns = max(partial_n_step_returns, expect + margin(action, selected_action))
            n_step_returns = n_step_returns + partial_n_step_returns
            self.policy_network.train()
            # 오차역전파로 기울기 함수 학습 #
            self.policy_network.opt.zero_grad()
            # loss 계산 #
            # L2 정규화는 MSE로 대체 #
            loss = double_dqn_loss + l1 * margin_classification_loss + l2 * n_step_returns + l3 * torch.Tensor([self.policy_network.loss(state, next_state)]).to(self.device)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.policy_network.parameters(), 1.0)
            self.policy_network.opt.step()

    def sample_minibatch(self):
        # softmax 함수 사용 #
        if self.use_per:
            pass
        else:
            result = []
            for _ in range(self.n):
                choice = self.memory.sample()
                result.append(choice)
            return result

    def pretrain(self):
        for i in range(PRETRAIN_STEP):
            print(f"{i} pretrain step")
            self.train_network(pretrain=True)
            if i % self.frequency == 0:
                self.target_network.load_state_dict(self.policy_network.state_dict())

        ## Do pretrain for 1000 steps

    def train(self):
        ###### 1. DO NOT MODIFY FOR TESTING ######
        test_mean_episode_reward = deque(maxlen=20)
        test_over_reward = False
        test_min_episode = np.inf
        ###### 1. DO NOT MODIFY FOR TESTING ######
        env = self.env
        env.reset()
        env.render()
        dqfd_agent = self
        self.d_replay = get_demo_traj()
        for e in self.d_replay:
            for obj in e:
                self.memory.push(obj)
        self.td_errors = []
        # Do pretrain
        self.pretrain()
        ## TODO

        for e in range(self.n_EPISODES):
            ########### 2. DO NOT MODIFY FOR TESTING ###########
            test_episode_reward = 0
            ########### 2. DO NOT MODIFY FOR TESTING  ###########

            ## TODO
            done = False
            state = env.reset()
            state = torch.from_numpy(state).float().to(self.device)
            env.render()

            while not done:
                env.render()
                ## TODO
                action = dqfd_agent.get_action(state)
                ## TODO

                next_state, reward, done, _ = env.step(action)
                next_state = torch.from_numpy(next_state).float().to(self.device)
                to_append = [state.cpu().numpy(), action, reward, next_state.cpu().numpy(), done]
                self.memory.push(to_append)
                ########### 3. DO NOT MODIFY FOR TESTING ###########
                test_episode_reward += reward      
                ########### 3. DO NOT MODIFY FOR TESTING  ###########
                ## TODO
                if reward == 500:
                    reward += 100
                elif done:
                    reward = -100
                self.train_network(to_append)
                ########### 4. DO NOT MODIFY FOR TESTING  ###########
                if done:
                    test_mean_episode_reward.append(test_episode_reward)
                    if (np.mean(test_mean_episode_reward) > 475) and (len(test_mean_episode_reward)==20):
                        test_over_reward = True
                        test_min_episode = e
                ########### 4. DO NOT MODIFY FOR TESTING  ###########
                state = next_state
                ## TODO
            ########### 5. DO NOT MODIFY FOR TESTING  ###########
            if test_over_reward:
                print("END train function")
                break
            ########### 5. DO NOT MODIFY FOR TESTING  ###########
            if e % self.frequency == 0:
                self.target_network.load_state_dict(self.policy_network.state_dict())

        ########### 6. DO NOT MODIFY FOR TESTING  ###########
        return test_min_episode, np.mean(test_mean_episode_reward)
        ########### 6. DO NOT MODIFY FOR TESTING  ###########